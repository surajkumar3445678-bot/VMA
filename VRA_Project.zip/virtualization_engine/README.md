# virtualization_engine
Phase 2. Planned: package a QEMU aarch64 build as `libqemu.so`, launch it from Kotlin
(`GuestManager.boot`) with `-accel kvm` when `/dev/kvm` is usable, else `-accel tcg`.
Not implemented yet. Today `GuestManager` only detects files and reports why boot cannot start.
