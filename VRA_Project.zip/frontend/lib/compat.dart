/// Pure logic: decides which virtualization route a device can honestly use.
enum VirtMode { kvmQemu, avfRestricted, softwareEmulation, containerOnly }

class CompatReport {
  final bool kvmUsable;
  final bool avfFeature;
  final bool arm64;
  final int sdk;
  final int ramMb;
  final int freeStorageMb;
  final String kernel;
  final String abi;
  final String model;

  const CompatReport({
    required this.kvmUsable,
    required this.avfFeature,
    required this.arm64,
    required this.sdk,
    required this.ramMb,
    required this.freeStorageMb,
    required this.kernel,
    required this.abi,
    required this.model,
  });

  factory CompatReport.fromMap(Map<dynamic, dynamic> m) => CompatReport(
        kvmUsable: m['kvmUsable'] == true,
        avfFeature: m['avfFeature'] == true,
        arm64: m['arm64'] == true,
        sdk: (m['sdk'] as num?)?.toInt() ?? 0,
        ramMb: (m['ramMb'] as num?)?.toInt() ?? 0,
        freeStorageMb: (m['freeStorageMb'] as num?)?.toInt() ?? 0,
        kernel: (m['kernel'] as String?) ?? 'unknown',
        abi: (m['abi'] as String?) ?? 'unknown',
        model: (m['model'] as String?) ?? 'unknown',
      );

  VirtMode get mode {
    if (arm64 && kvmUsable) return VirtMode.kvmQemu;
    if (avfFeature) return VirtMode.avfRestricted;
    if (arm64) return VirtMode.softwareEmulation;
    return VirtMode.containerOnly;
  }

  bool get enoughResources => ramMb >= 3000 && freeStorageMb >= 8000;

  String get title {
    switch (mode) {
      case VirtMode.kvmQemu:
        return 'Hardware virtualization available';
      case VirtMode.avfRestricted:
        return 'Android Virtualization Framework present, but restricted';
      case VirtMode.softwareEmulation:
        return 'Software emulation only';
      case VirtMode.containerOnly:
        return 'Full virtual Android not possible';
    }
  }

  /// Plain-language explanation. Never claims more than the probe found.
  String get explanation {
    switch (mode) {
      case VirtMode.kvmQemu:
        return '/dev/kvm is accessible to this app. A QEMU guest with its own kernel is possible once a guest image and QEMU build are installed.';
      case VirtMode.avfRestricted:
        return 'This device ships AVF, but custom VMs need a system-level permission that regular apps cannot get. VRA cannot use it on a normal install.';
      case VirtMode.softwareEmulation:
        return 'No usable /dev/kvm. QEMU can emulate a guest with its own kernel in software (TCG). It works in principle but is very slow, so expect long boot times.';
      case VirtMode.containerOnly:
        return 'This CPU is not ARM64. A container is the only fallback, and a container shares the host kernel, so it is NOT a separate Android kernel.';
    }
  }

  List<String> get warnings => [
        if (!enoughResources)
          'Needs at least 3 GB RAM and 8 GB free storage for a guest.',
        if (sdk < 26) 'Android 8.0 or newer is required.',
      ];
}
