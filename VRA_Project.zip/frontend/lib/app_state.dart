import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'compat.dart';
import 'host_bridge.dart';
import 'root_policy.dart';

class AppState extends ChangeNotifier {
  CompatReport? compat;
  Map<dynamic, dynamic> guest = {};
  String? bootMessage;
  final RootPolicy root = RootPolicy();
  bool shareClipboard = false;
  bool shareFiles = false;
  bool onboarded = false;
  SharedPreferences? _p;

  bool get guestInstalled => guest['installed'] == true;
  // No guest launcher is implemented yet, so a guest is never reported running.
  bool get guestRunning => false;

  Future<void> init() async {
    final p = await SharedPreferences.getInstance();
    _p = p;
    onboarded = p.getBool('onboarded') ?? false;
    shareClipboard = p.getBool('shareClipboard') ?? false;
    shareFiles = p.getBool('shareFiles') ?? false;
    final j = p.getString('rootPolicy');
    if (j != null) root.loadJson(jsonDecode(j));
    await refresh();
  }

  Future<void> refresh() async {
    try {
      compat = CompatReport.fromMap(await HostBridge.hostInfo());
      guest = await HostBridge.guestStatus();
    } catch (e) {
      bootMessage = 'Host probe failed: $e';
    }
    notifyListeners();
  }

  Future<void> boot() async {
    final r = await HostBridge.bootGuest();
    bootMessage = r['reason']?.toString() ?? 'No response';
    notifyListeners();
  }

  Future<void> setOnboarded() async {
    onboarded = true;
    await _p?.setBool('onboarded', true);
    notifyListeners();
  }

  Future<void> setShare({bool? clipboard, bool? files}) async {
    if (clipboard != null) {
      shareClipboard = clipboard;
      await _p?.setBool('shareClipboard', clipboard);
    }
    if (files != null) {
      shareFiles = files;
      await _p?.setBool('shareFiles', files);
    }
    notifyListeners();
  }

  Future<void> saveRoot() async {
    await _p?.setString('rootPolicy', jsonEncode(root.toJson()));
    notifyListeners();
  }
}
