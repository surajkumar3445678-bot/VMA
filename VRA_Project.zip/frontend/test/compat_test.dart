import 'package:flutter_test/flutter_test.dart';
import 'package:vra/compat.dart';

CompatReport r({bool kvm = false, bool avf = false, bool arm = true, int ram = 6000, int disk = 20000}) =>
    CompatReport(kvmUsable: kvm, avfFeature: avf, arm64: arm, sdk: 34, ramMb: ram, freeStorageMb: disk, kernel: 'k', abi: 'arm64-v8a', model: 'm');

void main() {
  test('kvm on arm64 gives kvmQemu', () => expect(r(kvm: true).mode, VirtMode.kvmQemu));
  test('avf flag alone is restricted', () => expect(r(avf: true).mode, VirtMode.avfRestricted));
  test('arm64 without kvm is software emulation', () => expect(r().mode, VirtMode.softwareEmulation));
  test('non-arm64 is container only and says so', () {
    final x = r(arm: false);
    expect(x.mode, VirtMode.containerOnly);
    expect(x.explanation, contains('NOT a separate Android kernel'));
  });
  test('low resources warn', () => expect(r(ram: 2000).warnings, isNotEmpty));
}
