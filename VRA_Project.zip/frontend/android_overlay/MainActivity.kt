package dev.vra.app

import dev.vra.host.GuestManager
import dev.vra.host.HostInspector
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "dev.vra/host")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "hostInfo" -> result.success(HostInspector.hostInfo(this))
                    "guestStatus" -> result.success(GuestManager.status(this))
                    "bootGuest" -> result.success(GuestManager.boot(this))
                    else -> result.notImplemented()
                }
            }
    }
}
