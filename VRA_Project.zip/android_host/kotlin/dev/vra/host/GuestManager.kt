package dev.vra.host

import android.content.Context
import java.io.File

/** Locates guest files. Launching QEMU is not implemented yet and says so. */
object GuestManager {
    private fun image(ctx: Context) = File(ctx.filesDir, "guest/system.img")
    private fun qemu(ctx: Context) = File(ctx.applicationInfo.nativeLibraryDir, "libqemu.so")

    fun status(ctx: Context): Map<String, Any> {
        val img = image(ctx)
        return mapOf(
            "installed" to img.isFile,
            "imagePath" to img.absolutePath,
            "imageBytes" to (if (img.isFile) img.length() else 0L),
            "qemuPresent" to qemu(ctx).isFile,
        )
    }

    fun boot(ctx: Context): Map<String, Any> {
        if (!image(ctx).isFile)
            return mapOf("ok" to false, "reason" to "No guest image at ${image(ctx).absolutePath}.")
        if (!qemu(ctx).isFile)
            return mapOf("ok" to false, "reason" to "No QEMU binary packaged with this build.")
        return mapOf("ok" to false, "reason" to "Image and QEMU found, but the QEMU launcher is not implemented in this build, so nothing was started.")
    }
}
